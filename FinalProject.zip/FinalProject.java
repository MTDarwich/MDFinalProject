from abc import ABC, abstractmethod

class Drivable(ABC):
    @abstractmethod
    def drive(self):
        pass

class ElectricVehicle:
    def __init__(self, make, model, year, battery_level):
        self.make = make
        self.model = model
        self.year = year
        self.battery_level = battery_level

    @abstractmethod
    def charge(self):
        pass

    def getBatteryLevel(self):
        return f"Battery level of {self.make} {self.model} is {self.battery_level}%"

class Vehicle(Drivable):
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
    
    def getInfo(self):
        return f"{self.year} {self.make} {self.model}"

    def drive(self):
        return f"Driving {self.make} {self.model}!"

class Car(Vehicle):
    def __init__(self, make, model, year, passengers):
        super().__init__(make, model, year)
        self.passengers = passengers
    
    def getInfo(self):
        return f"{self.year} {self.make} {self.model} with {self.passengers} passengers"

    def drive(self):
        return f"Driving {self.make} {self.model} as a car with {self.passengers} passengers."

class Truck(Vehicle):
    def __init__(self, make, model, year, cargo_capacity):
        super().__init__(make, model, year)
        self.cargo_capacity = cargo_capacity
    
    def getInfo(self):
        return f"{self.year} {self.make} {self.model} with {self.cargo_capacity} kg cargo capacity"

    def drive(self):
        return f"Driving {self.make} {self.model} as a truck with {self.cargo_capacity} kg cargo capacity."

class ElectricCar(ElectricVehicle, Car):
    def __init__(self, make, model, year, battery_level, passengers):
        ElectricVehicle.__init__(self, make, model, year, battery_level)
        Car.__init__(self, make, model, year, passengers)

    def charge(self):
        self.battery_level = 100
        return f"Charging {self.make} {self.model}. Battery is now full!"

    def drive(self):
        return f"Driving the electric car {self.make} {self.model}."

class ElectricTruck(ElectricVehicle, Truck):
    def __init__(self, make, model, year, battery_level, cargo_capacity):
        ElectricVehicle.__init__(self, make, model, year, battery_level)
        Truck.__init__(self, make, model, year, cargo_capacity)

    def charge(self):
        self.battery_level = 100
        return f"Charging {self.make} {self.model} electric truck. Battery is now full!"

    def drive(self):
        return f"Driving the electric truck {self.make} {self.model} with {self.cargo_capacity} kg of cargo."


def test_simulation():
    vehicle = Vehicle("Generic", "Model 1", 2024)
    car = Car("Toyota", "Camry", 2024, 5)
    truck = Truck("Ford", "F-150", 2024, 1000)
    electric_car = ElectricCar("Tesla", "Model S", 2024, 80, 4)
    electric_truck = ElectricTruck("Rivian", "R1T", 2024, 60, 2000)

    print(vehicle.getInfo())
    print(vehicle.drive())

    print(car.getInfo())
    print(car.drive())

    print(truck.getInfo())
    print(truck.drive())

    print(electric_car.getInfo())
    print(electric_car.getBatteryLevel())
    print(electric_car.charge())
    print(electric_car.drive())

    print(electric_truck.getInfo())
    print(electric_truck.getBatteryLevel())
    print(electric_truck.charge())
    print(electric_truck.drive())

test_simulation()
